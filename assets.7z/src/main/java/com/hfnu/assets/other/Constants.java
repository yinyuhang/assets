package com.hfnu.assets.other;

public class Constants {
    public static final String LEND = "lend";
    public static final String AVAILABLE = "available";
    public static final String SCRAP = "scrap";
}
